from flask import Blueprint
from flask import Flask, url_for, redirect, render_template
from flask import request, session
import mysql.connector

#assignment10 blueprint definition
assignment10 = Blueprint('assignment10', __name__, static_folder='static',
                         static_url_path="/assignment10",
                         template_folder='templates')

# Routes
@assignment10.route('/assignment10', methods=['GET', 'POST'])
def assignment10_func():
    if request.method == 'POST':
        email = request.form['email']
        firstName = request.form['firstName']
        country = request.form['country']
        city = request.form['city']
        age = request.form['age']
        query = "INSERT INTO users(email, firstName, country, city, age) VALUES ('%s', '%s', '%s', '%s', '%s')" % (email, firstName, country, city, age)
        return_value = interact_db(query, 'commit')
        readUser = "SELECT * FROM users WHERE email='%s';" % email
        wantedUser = interact_db(readUser, 'fetch')
        RefreshUsersList = "SELECT * FROM users"
        query_result = interact_db(RefreshUsersList, 'fetch')
        return render_template('Assignment10.html', wantedUser=wantedUser[0], users=query_result)

    else:
        query = "SELECT * FROM users"
        query_result = interact_db(query, 'fetch')
        return render_template('assignment10.html', users=query_result)


@assignment10.route('/assignment10/deletion', methods=['GET', 'POST'])
def assignment10Delete_func():

    if request.method == 'GET':
        userID = request.args['userID']
        query = "DELETE FROM users WHERE userID='%s';" % userID
        interact_db(query, query_type='commit')
    return redirect('/assignment10')

@assignment10.route('/assignment10/update', methods=['GET', 'POST'])
def assignment10Update_func():

    if request.method == 'POST':
        userID = request.form['userID']

        setQuery = ""

        for key in request.form:
           value = request.form[key]
           if key != 'userID' and value != '':
               setQuery += key + "='" + value + "' ,"

        setQuery = setQuery[:-1]

        query = "UPDATE users SET " + setQuery + " WHERE userID='%s';" % userID
        interact_db(query, query_type='commit')

    return redirect('/assignment10')


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root', database='danielassignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        #Used for insert, update or delete statements.
        #Returns the number of rows affected by the query (a non-negative int)
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        #Use for select statement.
        #Returns: False if the query failed, or the result of the query is successful.
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value
