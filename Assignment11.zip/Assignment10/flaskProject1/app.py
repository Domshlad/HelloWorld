from flask import Flask, redirect, url_for, render_template
from flask import request, session
from flask import jsonify
import mysql.connector

app = Flask(__name__)
app.secret_key = '123'

@app.route('/homepage')
@app.route('/')
def homepage_func():
    return render_template('Homepage.html', username=session.get('username'))

@app.route('/contact')
def Contact_func():
    return render_template('Contact.html', username=session.get('username'))

@app.route('/cv')
def CV_func():
    return render_template('CV.html', username=session.get('username'))

@app.route('/userExtraction')
def UserExtraction_func():
    return render_template('UserExtraction.html',username=session.get('username'))

@app.route('/assignment8', )
def assignment8Open():
    # Getting the name from the user
    user_from_db = {'firstName': 'Daniel', 'lastName': 'Domshlak', 'gender': 'girl', 'email' : 'domshlad@post.bgu.ac.il', 'age' : 27, 'status' : 'Single'}

    return render_template('Assignment8.html', user=user_from_db, hobbies=['Running', 'Singing', 'Playing Guitar', 'Working Out'],
                           animals=('Bardelas', 'Cats', 'Tigers', 'Dolphins'), username=session.get('username'))

@app.route('/duplicated8')
def user_func():

    # get the name of the user
    user_from_db = {'firstName': 'Daniel', 'lastName': 'Domshlak', 'gender': 'girl', 'email' : 'domshlad@post.bgu.ac.il', 'age' : 27, 'status' : 'Single'}

    return render_template('duplicated8.html', user=user_from_db, hobbies=['Running', 'Singing', 'Playing Guitar', 'Working Out'],
                           animals=('Bardelas', 'Cats', 'Tigers', 'Dolphins'))

# Lecture 10

from Pages.Assignment10.assignment10 import assignment10
app.register_blueprint(assignment10)

@app.route('/about')
def about_func():
    if 'name' in request.args:
        name=request.args['name']
        return render_template('about.html', name=name)
    return render_template('about.html')


@app.route('/logout', methods=['GET'])
def logout():
    session['username'] = None

    return render_template('assignment9.html', request_method=request.method)

@app.route('/assignment9', methods=['GET','POST'])
def assignment9_func():
    users = [
        {'userName': 'Daniel', 'password': 'Domshlak', 'email' : 'domshlad@post.bgu.ac.il', 'firstName' : 'Dani', 'country': 'Israel', 'city' :'Beer Sheva', 'age': '27'},
        {'userName': 'Yosskele', 'password': '32423', 'email': 'ddman@post.bgu.ac.il', 'firstName' : 'Yossi', 'country': 'Russia', 'city' :'Moskwa', 'age': '33'},
        {'userName': 'ZoharTyTy', 'password': '432432', 'email': 'tdman@post.bgu.ac.il', 'firstName' : 'Zohar', 'country': 'Holand', 'city' :'Amsterdam', 'age': '22'},
    ]
    filteredUsers=[]
    # Initialize a new array called filteredUsers
    if request.method =='POST':
        # check in DB of the website
        password = request.form['password']
        email = request.form['email']
        session['username'] = request.form['username']
    else:
        searchResultEmail = request.args.get('email')

        if searchResultEmail == '':
            filteredUsers = users
        else:
            for user in users:
                if user['email']==searchResultEmail:
                    filteredUsers.append(user)
        #Iterate the users list
        #If the user's email equals the parm email - add it to the filteredUsers list

    return render_template('assignment9.html', request_method=request.method, username=session.get('username'), users=filteredUsers)

#Assignment 11

@app.route('/assignment11/users')
def getAllUsers():
    query="SELECT * FROM users"
    query_result = interact_db(query, 'fetch')
    data = list(map(lambda row:row._asdict(), query_result))
    return render_template('assignment11.html', data=data)

@app.route('/assignment11/users/selected', defaults={'userID':5})
@app.route('/assignment11/users/selected/<int:userID>')
def get_user(userID = None):
    if userID:
        query = "SELECT * FROM users WHERE userID=%s LIMIT 1" % userID
        query_result = interact_db(query, 'fetch')
        if query_result:
            data = list(map(lambda row: row._asdict(), query_result))
            return render_template('assignment11.html', data=data[0])
        else:
            return 'Error'


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root', database='danielassignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        #Used for insert, update or delete statements.
        #Returns the number of rows affected by the query (a non-negative int)
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        #Use for select statement.
        #Returns: False if the query failed, or the result of the query is successful.
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value


if __name__ == '__main__':
    app.run(debug=True)

