from flask import Flask, redirect, url_for, render_template

app = Flask(__name__)

@app.route('/homepage')
@app.route('/')
def homepage_func():
    return render_template('Homepage.html')

@app.route('/contact')
def Contact_func():
    return render_template('Contact.html')

@app.route('/cv')
def CV_func():
    return render_template('CV.html')

@app.route('/userExtraction')
def UserExtraction_func():
    return render_template('UserExtraction.html')

@app.route('/assignment8')
def assignment8Open():
    # Getting the name from the user
    user_from_db = {'firstName': 'Daniel', 'lastName': 'Domshlak', 'gender': 'girl', 'email' : 'domshlad@post.bgu.ac.il', 'age' : 27, 'status' : 'Single'}

    return render_template('Assignment8.html', user=user_from_db, hobbies=['Running', 'Singing', 'Playing Guitar', 'Working Out'],
                           animals=('Bardelas', 'Cats', 'Tigers', 'Dolphins'))


@app.route('/duplicated8')
def user_func():
    # get the name of the user
    user_from_db = {'firstName': 'Daniel', 'lastName': 'Domshlak', 'gender': 'girl', 'email' : 'domshlad@post.bgu.ac.il', 'age' : 27, 'status' : 'Single'}

    return render_template('duplicated8.html', user=user_from_db, hobbies=['Running', 'Singing', 'Playing Guitar', 'Working Out'],
                           animals=('Bardelas', 'Cats', 'Tigers', 'Dolphins'))


if __name__ == '__main__':
    app.run(debug=True)
